﻿namespace Bloxstrap.Enums.FlagPresets
{
    public enum LightingMode
    {
        Default,
        Voxel,
        ShadowMap,
        Future
    }
}
